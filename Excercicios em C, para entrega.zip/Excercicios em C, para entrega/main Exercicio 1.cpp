#include <stdio.h>

int main(void) {
	
	for(int i = 1; i <= 100; i++){
		
		printf("N�meros: %i \n", i);
	
	}
	

	return 0;
}
